mascotas = ["hola", "como", "estas", "hoy"]

for indice, mascota in enumerate(mascotas):  # enumerate retorna una TUPLA
    print(indice, mascota)
