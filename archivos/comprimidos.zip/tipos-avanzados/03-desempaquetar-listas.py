numeros = [1, 2, 3]

# extrae los elementos dentro del listado asignandolos a las variables por orden
primero, segundo, tercero = numeros
# extrae los elementos dentro del listado guardando el primer dato y el resto los guarda en otros
primero, *otros = numeros
# extrae el primer elemento y el ultimo de la lista
primero, *otros, ultimo = numeros
