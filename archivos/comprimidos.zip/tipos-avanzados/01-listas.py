numeros = [1, 2, 3]
letras = ["a", "b", "c"]
palabras = ["trabaja", "plasma", "las", "palabras"]
booleans = [True, False]
matriz = [[0, 1], [1, 0]]
ceros = [0, 1] * 10  # multiplica los datos dentro del array por x veces
alfanumerico = numeros + letras

# metodo que crea listas y se le pasa el iterable de range
rango = list(range(1, 11))
chars = list("hola mundo")  # se le entrega un iterable en este caso un string

print(chars)
