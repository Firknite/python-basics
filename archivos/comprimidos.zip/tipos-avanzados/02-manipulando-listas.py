mascotas = ["benito", "sammy", "arriety", "morita", "kishi"]

print(mascotas[0:3])
print(mascotas[2:])
print(mascotas[-1])  # recupera el objeto del array de derecha a izquierda
print(mascotas[::2])  # avanza recuperando solamente un elemento por medio

# avanza recuperando solamente un elemento por medio partiendo desde un indice especifico
print(mascotas[1::2])

numeros = list(range(1, 21))
print(numeros[::4])
