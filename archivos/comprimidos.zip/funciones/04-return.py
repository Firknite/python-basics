def suma(a, b):
    return a + b


c = suma(5, 3)
print(c)
