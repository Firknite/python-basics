def get_product(**datos):
    print(datos["id"], datos["name"])


get_product(id="23",
            name="iPhone",
            desc="Esto es un iphone")


# LOS 2 * SON PARA INDICAR QUE LA FUNCION VA A RECIBIR MULTIPLES PARAMETROS
# PERO QUE DEBEN SER MENCIONADOS AL MOMENTO DE SER ENTREGADOS COMO ARGUMENTOS
