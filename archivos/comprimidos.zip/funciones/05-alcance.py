def saludar():
    saludo = "Hola Mundo"
    print(id(saludo))


def saludarChanchito():
    saludo = "Hola Chanchito"
    print(id(saludo))


saludar()
saludarChanchito()
