def hola(nombre, apellido="feliz"):
    print("Hola mundo")
    print(f"Bienvenido {nombre} {apellido}")


hola(nombre="Rigoberto", apellido="Torres")
