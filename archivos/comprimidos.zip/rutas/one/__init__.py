def init(graphql, **_):
    print(f"Modulo 1: {graphql}")
