def init(db, api, **_):
    print(f"Modulo 2: {db} {api}")
