from usuarios.impuestos.utilidades import pagar_impuestos

# import usuarios

pagar_impuestos()
# print(dir(usuarios))
# print(usuarios.__path__)
