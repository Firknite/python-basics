# and, or, not

gas = False
encendido = True
edad = 18

if gas and encendido and edad > 18:
    print("Puede avanzar")
