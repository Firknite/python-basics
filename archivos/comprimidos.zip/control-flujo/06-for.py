buscar = 3

for numero in range(5):
    if numero == buscar:
        print("encontrado", buscar)
        break
else:
    print("No encontré el número buscado :(")


for char in "Ultimate Python":
    print(char)
