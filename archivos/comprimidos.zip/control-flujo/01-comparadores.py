# > mayor que
# < menor que
# <= menor igual que
# >= mayor igual que
# == es igual que
# != distinto que
