edad = 25

if 15 <= edad <= 65:
    print("Puede entrar a la piscina")
