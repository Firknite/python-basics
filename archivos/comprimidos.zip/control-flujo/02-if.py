edad = 22

if edad > 17:
    print("Puede ver la película")
elif edad > 60:
    print("No puedes entrar")
else:
    print("No puedes entrar")

print("Listo")
