EDAD = 15

MENSAJE = "Es mayor" if EDAD > 17 else "Es menor"

# if edad > 17:
#     mensaje = "Es mayor"
# else:
#     mensaje = "Es menor"

print(MENSAJE)
