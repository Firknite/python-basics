x = input("")

# int()
# str()
# float()
# bool()
