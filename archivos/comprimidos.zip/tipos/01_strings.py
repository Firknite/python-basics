"""Metodos de string para pyton"""

Nombre_Curso = "Ultimate Python"
Descripcion_curso = """
Ultimate python es un curso contemplativo
que contiene todos los detalles que 
necesitas aprender para encontrar trabajo 
como desarrollador python
"""

print(len(Nombre_Curso))
print(Nombre_Curso[0])
print(Nombre_Curso[0:8])
print(Nombre_Curso[9:])
print(Nombre_Curso[:8])
print(Nombre_Curso[:])
