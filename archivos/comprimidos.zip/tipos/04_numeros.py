NUMERO = 2  # integer
DECIMAL = 1.2  # float
IMAGINARIO = 2 + 2j

NUMERO += 2
NUMERO -= 2
NUMERO *= 2
NUMERO /= 2

print(3 // 2)  # division sin decimales
print(8 % 3)  # modulo
