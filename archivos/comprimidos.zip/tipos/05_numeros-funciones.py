import math

print(round(1.3))
print(round(1.7))
print(round(1.5))
print(abs(-77))

print(math.ceil(1.1))  # lo lleva al numero entero superior mas cercano
print(math.floor(1.999))  # lo lleva al numero entero inferior mas cercano
print(math.isnan(23))
print(math.pow(10, 3))  # potencia un numero con su respectivo exponente
print(math.sqrt(9))  # calcula la raiz cuadrada


# todos los metodos de math en https://docs.python.org/3/library/math.html
